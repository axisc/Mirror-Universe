package mirroruniverse.g1_final;

public class MapData {

	static final int PLAYERPOSITION = 3;
	static final int WALL = 1;
	static final int OBSTACLE = 1;
	static final int EXIT =2;
	static final int UNKNOWN =4;
	static final int FREESPACE = 0;
}
